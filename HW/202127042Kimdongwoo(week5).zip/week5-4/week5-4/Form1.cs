﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Nakov.TurtleGraphics;

namespace week5_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load; // 폼 로드 이벤트에 메서드 연결
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DisplayCurrentTime(); // 폼이 로드될 때 현재 시간 표시
        }

        private void DisplayCurrentTime()
        {
            // 현재 시간을 "시:분:초" 형태로 텍스트 박스에 설정
            label1.Text = DateTime.Now.ToString("HH:mm:ss");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int swidth = 600, sheight = 600;
            this.ClientSize = new Size(swidth, sheight);
            Turtle.Delay = 50;

            // 현재 시간 가져오기
            DateTime currentTime = DateTime.Now;
            int hour = currentTime.Hour % 12; // 12-hour format
            int minute = currentTime.Minute;
            int second = currentTime.Second;

            // 시간에 따른 시계 그리기
            DrawClock(hour, minute, second);
        }

        private void DrawClock(int hour, int minute, int second)
        {
            // 시계판 그리기
            DrawClockFace();

            // 시침 그리기
            DrawHand(hour * 30 + minute / 2, Color.Red, 15);

            // 분침 그리기
            DrawHand(minute * 6 + second / 10, Color.Blue, 10);

            // 초침 그리기
            DrawHand(second * 6, Color.Yellow, 5);
        }

        private void DrawClockFace()
        {
            Turtle.Reset();
            Turtle.Angle = 0;
            for (int i = 0; i < 12; i++)
            {
                Turtle.PenColor = Color.Gray;
                Turtle.PenUp();
                Turtle.MoveTo(0, 0);
                Turtle.PenDown();
                Turtle.RotateTo(i * 30);
                Turtle.Forward(150);
            }
        }

        private void DrawHand(float angle, Color color, int penSize)
        {
            Turtle.PenColor = color;
            Turtle.PenSize = penSize;
            Turtle.PenUp();
            Turtle.MoveTo(0, 0);
            Turtle.PenDown();
            Turtle.RotateTo(angle);
            Turtle.Forward(100); // 침의 길이는 100으로 가정
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Turtle.Reset();
        }
    }
}
