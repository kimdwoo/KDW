﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week5_2
{
    class RockPaperScissors
    {
        static void Main()
        {
            int iR = 0;
            int iS = 0;
            String[] Choice = { "가위", "바위", "보" };

            iR = (new Random()).Next(1, 4);

            Console.Write("1(가위),2(바위),3(보) 입력 : _\b");
            iS = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\n사용자 :{0}", Choice[iR - 1]);
            Console.WriteLine("컴퓨터:{0}\n", Choice[iR - 1]);
            if (iS == iR)
            {
                Console.WriteLine("비김");

            }
            else
            {
                switch (iS)
                {
                    case 1: Console.WriteLine((iR == 3) ? "승" : "패"); break;
                    case 2: Console.WriteLine((iR == 1) ? "승" : "패"); break;
                    case 3: Console.WriteLine((iR == 2) ? "승" : "패"); break;

                }
            }
        }
    }
}

